
package umg.DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import umg.modelo.Camion;


public class CamionDAO {
     private static final String COLS = "idCamion, NoPlaca, Modelo, Tipo, Potencia";

    private Camion map(ResultSet rs) throws SQLException {
        Camion c = new Camion();
        c.setIdCamion(rs.getInt(1));
        c.setNoPlaca(rs.getString(2));
        c.setModelo(rs.getString(3));
        c.setTipo(rs.getString(4));
        c.setPotencia(rs.getInt(5));
        return c;
    }
    public void crear (Camion c) throws SQLException{
        String sql = "INSERT INTO Camion(NoPlaca, Modelo, Tipo, Potencia) VALUES(?,?,?,?)";
        try (Connection cn = ConexionDB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, c.getNoPlaca());
            ps.setString(2, c.getModelo());
            ps.setString(3, c.getTipo());
            ps.setInt(4, c.getPotencia());
            ps.executeUpdate();
        }
    }
    public List<Camion> listar() throws SQLException {
        List<Camion> lista = new ArrayList<>();
        try (Connection cn = ConexionDB.getConnection(); Statement st = cn.createStatement();
             ResultSet rs = st.executeQuery("SELECT " + COLS + " FROM Camion ORDER BY idCamion")) {
            while (rs.next()) lista.add(map(rs));
        }
        return lista;
    }

    public Camion buscarPorId(int id) throws SQLException {
        try (Connection cn = ConexionDB.getConnection();
             PreparedStatement ps = cn.prepareStatement("SELECT " + COLS + " FROM Camion WHERE idCamion=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    /** Devuelve true si ya existe otro camion con esa placa (excluyendo idExcluir). */
    public boolean existePlaca(String placa, int idExcluir) throws SQLException {
        String sql = "SELECT 1 FROM Camion WHERE NoPlaca=? AND idCamion<>?";
        try (Connection cn = ConexionDB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, placa);
            ps.setInt(2, idExcluir);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public boolean actualizar(Camion c) throws SQLException {
        String sql = "UPDATE Camion SET NoPlaca=?, Modelo=?, Tipo=?, Potencia=? WHERE idCamion=?";
        try (Connection cn = ConexionDB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, c.getNoPlaca());
            ps.setString(2, c.getModelo());
            ps.setString(3, c.getTipo());
            ps.setInt(4, c.getPotencia());
            ps.setInt(5, c.getIdCamion());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean eliminar(int id) throws SQLException {
        try (Connection cn = ConexionDB.getConnection();
             PreparedStatement ps = cn.prepareStatement("DELETE FROM Camion WHERE idCamion=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }
}
    
