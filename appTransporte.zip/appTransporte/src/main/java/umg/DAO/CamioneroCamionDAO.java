
package umg.DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import umg.modelo.CamioneroCamion;

public class CamioneroCamionDAO {
    private static final String SELECT =
        "SELECT cc.idCamioneroCamion, cc.idCamionero, cc.idCamion, cr.Nombre, c.NoPlaca "
      + "FROM CamioneroCamion cc LEFT JOIN Camionero cr ON cc.idCamionero = cr.idCamionero "
      + "LEFT JOIN Camion c ON cc.idCamion = c.idCamion ";

    private CamioneroCamion map(ResultSet rs) throws SQLException {
        CamioneroCamion x = new CamioneroCamion();
        x.setIdCamioneroCamion(rs.getInt(1));
        x.setIdCamionero(rs.getInt(2));
        x.setIdCamion(rs.getInt(3));
        x.setNombreCamionero(rs.getString(4));
        x.setPlacaCamion(rs.getString(5));
        return x;
    }

    public void crear(CamioneroCamion x) throws SQLException {
        String sql = "INSERT INTO CamioneroCamion(idCamionero, idCamion) VALUES(?,?)";
        try (Connection cn = ConexionDB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, x.getIdCamionero());
            ps.setInt(2, x.getIdCamion());
            ps.executeUpdate();
        }
    }

    public List<CamioneroCamion> listar() throws SQLException {
        List<CamioneroCamion> lista = new ArrayList<>();
        try (Connection cn = ConexionDB.getConnection(); Statement st = cn.createStatement();
             ResultSet rs = st.executeQuery(SELECT + "ORDER BY cc.idCamioneroCamion")) {
            while (rs.next()) lista.add(map(rs));
        }
        return lista;
    }

    public CamioneroCamion buscarPorId(int id) throws SQLException {
        try (Connection cn = ConexionDB.getConnection();
             PreparedStatement ps = cn.prepareStatement(SELECT + "WHERE cc.idCamioneroCamion=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    /** Evita asignaciones duplicadas (mismo camionero + mismo camion). */
    public boolean existeAsignacion(int idCamionero, int idCamion, int idExcluir) throws SQLException {
        String sql = "SELECT 1 FROM CamioneroCamion WHERE idCamionero=? AND idCamion=? AND idCamioneroCamion<>?";
        try (Connection cn = ConexionDB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, idCamionero);
            ps.setInt(2, idCamion);
            ps.setInt(3, idExcluir);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public boolean actualizar(CamioneroCamion x) throws SQLException {
        String sql = "UPDATE CamioneroCamion SET idCamionero=?, idCamion=? WHERE idCamioneroCamion=?";
        try (Connection cn = ConexionDB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, x.getIdCamionero());
            ps.setInt(2, x.getIdCamion());
            ps.setInt(3, x.getIdCamioneroCamion());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean eliminar(int id) throws SQLException {
        try (Connection cn = ConexionDB.getConnection();
             PreparedStatement ps = cn.prepareStatement("DELETE FROM CamioneroCamion WHERE idCamioneroCamion=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }
}


