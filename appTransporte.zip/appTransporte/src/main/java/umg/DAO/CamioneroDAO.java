
package umg.DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import umg.modelo.Camionero;

public class CamioneroDAO {
    private static final String COLS = "idCamionero, Nombre, Telefono, Direccion, Salario, Poblacion";

    private Camionero map(ResultSet rs) throws SQLException {
        Camionero c = new Camionero();
        c.setIdCamionero(rs.getInt(1));
        c.setNombre(rs.getString(2));
        c.setTelefono(rs.getString(3));
        c.setDireccion(rs.getString(4));
        c.setSalario(rs.getDouble(5));
        c.setPoblacion(rs.getString(6));
        return c;
    }

    public void crear(Camionero c) throws SQLException {
        String sql = "INSERT INTO Camionero(Nombre, Telefono, Direccion, Salario, Poblacion) VALUES(?,?,?,?,?)";
        try (Connection cn = ConexionDB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, c.getNombre());
            ps.setString(2, c.getTelefono());
            ps.setString(3, c.getDireccion());
            ps.setDouble(4, c.getSalario());
            ps.setString(5, c.getPoblacion());
            ps.executeUpdate();
        }
    }

    public List<Camionero> listar() throws SQLException {
        List<Camionero> lista = new ArrayList<>();
        try (Connection cn = ConexionDB.getConnection(); Statement st = cn.createStatement();
             ResultSet rs = st.executeQuery("SELECT " + COLS + " FROM Camionero ORDER BY idCamionero")) {
            while (rs.next()) lista.add(map(rs));
        }
        return lista;
    }

    public Camionero buscarPorId(int id) throws SQLException {
        try (Connection cn = ConexionDB.getConnection();
             PreparedStatement ps = cn.prepareStatement("SELECT " + COLS + " FROM Camionero WHERE idCamionero=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    public boolean actualizar(Camionero c) throws SQLException {
        String sql = "UPDATE Camionero SET Nombre=?, Telefono=?, Direccion=?, Salario=?, Poblacion=? WHERE idCamionero=?";
        try (Connection cn = ConexionDB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, c.getNombre());
            ps.setString(2, c.getTelefono());
            ps.setString(3, c.getDireccion());
            ps.setDouble(4, c.getSalario());
            ps.setString(5, c.getPoblacion());
            ps.setInt(6, c.getIdCamionero());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean eliminar(int id) throws SQLException {
        try (Connection cn = ConexionDB.getConnection();
             PreparedStatement ps = cn.prepareStatement("DELETE FROM Camionero WHERE idCamionero=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }
}

    
