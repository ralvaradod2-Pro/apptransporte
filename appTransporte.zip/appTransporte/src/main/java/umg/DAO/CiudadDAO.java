
package umg.DAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import umg.modelo.Ciudad;

public class CiudadDAO {
    public void crear (Ciudad c )throws SQLException{
           String sql = "INSERT INTO Ciudad(Nombre) VALUES(?)";
        try (Connection cn = ConexionDB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, (String) c.getNombre());
            ps.executeUpdate();
            
    }
}

public List<Ciudad> listar () throws SQLException{
    List<Ciudad> lista = new ArrayList<>();
    String sql = "SELECT idCiudad, Nombre FROM Ciudad ORDER BY idCiudad";
        try (Connection cn = ConexionDB.getConnection(); Statement st = cn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) lista.add(new Ciudad(rs.getInt(1), rs.getString(2)));
        }
        return lista;
    
}
public Ciudad buscarPorId(int id) throws SQLException {
    String sql = "SELECT idCiudad, Nombre FROM Ciudad WHERE idCiudad=?";
        try (Connection cn = ConexionDB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? new Ciudad(rs.getInt(1), rs.getString(2)) : null;
            }
        }
    }
public boolean actualizar (Ciudad c) throws SQLException{String sql = "UPDATE Ciudad SET Nombre=? WHERE idCiudad=?";
        try (Connection cn = ConexionDB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, (String) c.getNombre());
            ps.setInt(2, c.getIdCiudad());
            return ps.executeUpdate() > 0;
        }
    }
public boolean eliminar (int id) throws SQLException {
    String sql = "DELETE FROM Ciudad WHERE idCiudad=?";
        try (Connection cn = ConexionDB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }
}
