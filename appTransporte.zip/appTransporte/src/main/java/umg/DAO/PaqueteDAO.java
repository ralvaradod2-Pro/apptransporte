
package umg.DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import umg.modelo.Paquete;

public class PaqueteDAO {
    private static final String SELECT =
        "SELECT p.idPaquete, p.Descripcion, p.Destinatario, p.DireccionEnvio, p.idCamionero, p.idCiudad, "
      + "cr.Nombre, ci.Nombre "
      + "FROM Paquete p LEFT JOIN Camionero cr ON p.idCamionero = cr.idCamionero "
      + "LEFT JOIN Ciudad ci ON p.idCiudad = ci.idCiudad ";

    private Paquete map(ResultSet rs) throws SQLException {
        Paquete p = new Paquete();
        p.setIdPaquete(rs.getInt(1));
        p.setDescripcion(rs.getString(2));
        p.setDestinatario(rs.getString(3));
        p.setDireccionEnvio(rs.getString(4));
        p.setIdCamionero(rs.getInt(5));
        p.setIdCiudad(rs.getInt(6));
        p.setNombreCamionero(rs.getString(7));
        p.setNombreCiudad(rs.getString(8));
        return p;
    }

    public void crear(Paquete p) throws SQLException {
        String sql = "INSERT INTO Paquete(Descripcion, Destinatario, DireccionEnvio, idCamionero, idCiudad) VALUES(?,?,?,?,?)";
        try (Connection cn = ConexionDB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, p.getDescripcion());
            ps.setString(2, p.getDestinatario());
            ps.setString(3, p.getDireccionEnvio());
            ps.setInt(4, p.getIdCamionero());
            ps.setInt(5, p.getIdCiudad());
            ps.executeUpdate();
        }
    }

    public List<Paquete> listar() throws SQLException {
        List<Paquete> lista = new ArrayList<>();
        try (Connection cn = ConexionDB.getConnection(); Statement st = cn.createStatement();
             ResultSet rs = st.executeQuery(SELECT + "ORDER BY p.idPaquete")) {
            while (rs.next()) lista.add(map(rs));
        }
        return lista;
    }

    public Paquete buscarPorId(int id) throws SQLException {
        try (Connection cn = ConexionDB.getConnection();
             PreparedStatement ps = cn.prepareStatement(SELECT + "WHERE p.idPaquete=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    public boolean actualizar(Paquete p) throws SQLException {
        String sql = "UPDATE Paquete SET Descripcion=?, Destinatario=?, DireccionEnvio=?, idCamionero=?, idCiudad=? WHERE idPaquete=?";
        try (Connection cn = ConexionDB.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, p.getDescripcion());
            ps.setString(2, p.getDestinatario());
            ps.setString(3, p.getDireccionEnvio());
            ps.setInt(4, p.getIdCamionero());
            ps.setInt(5, p.getIdCiudad());
            ps.setInt(6, p.getIdPaquete());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean eliminar(int id) throws SQLException {
        try (Connection cn = ConexionDB.getConnection();
             PreparedStatement ps = cn.prepareStatement("DELETE FROM Paquete WHERE idPaquete=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }
}
