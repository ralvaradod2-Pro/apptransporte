package umg.UI;

import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import umg.DAO.*;
import umg.modelo.*;

public class AppTransporte {

    private static final CiudadDAO ciudadDAO = new CiudadDAO();
    private static final CamioneroDAO camioneroDAO = new CamioneroDAO();
    private static final CamionDAO camionDAO = new CamionDAO();
    private static final PaqueteDAO paqueteDAO = new PaqueteDAO();
    private static final CamioneroCamionDAO asignacionDAO = new CamioneroCamionDAO();

    private interface Accion { void run() throws SQLException; }

    /** Ejecuta una accion y maneja errores de BD de forma amigable. */
    private static void ejecutar(Accion a) {
        try {
            a.run();
        } catch (SQLIntegrityConstraintViolationException e) {
            System.out.println("  X Operacion no permitida: el registro esta relacionado con otros datos o esta duplicado.");
        } catch (SQLException e) {
            System.out.println("  X Error de base de datos: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        int op;
        do {
            System.out.println("\n===== SISTEMA DE TRANSPORTE - db_paqueteria =====");
            System.out.println("1. Camioneros\n2. Camiones\n3. Paquetes\n4. Camionero-Camion\n5. Ciudades\n0. Salir");
            op = Entrada.entero("Opcion", 0, 5);
            switch (op) {
                case 1: menuCamionero(); break;
                case 2: menuCamion(); break;
                case 3: menuPaquete(); break;
                case 4: menuAsignacion(); break;
                case 5: menuCiudad(); break;
                default: break;
            }
        } while (op != 0);
        System.out.println("Hasta luego.");
    }

    private static int submenu(String titulo) {
        System.out.println("\n--- " + titulo + " ---");
        System.out.println("1. Crear\n2. Listar\n3. Buscar por ID\n4. Actualizar\n5. Eliminar\n0. Volver");
        return Entrada.entero("Opcion", 0, 5);
    }

    // ---------------- CAMIONERO ----------------
    private static Camionero leerCamionero() {
        Camionero c = new Camionero();
        c.setNombre(Entrada.nombre("Nombre", 60));
        c.setTelefono(Entrada.telefono("Telefono (8 digitos)"));
        c.setDireccion(Entrada.texto("Direccion", 100));
        c.setSalario(Entrada.decimalPositivo("Salario (Q)"));
        c.setPoblacion(Entrada.nombre("Poblacion", 45));
        return c;
    }

    private static void menuCamionero() {
        int op;
        do {
            op = submenu("CAMIONEROS");
            switch (op) {
                case 1: ejecutar(() -> { camioneroDAO.crear(leerCamionero()); System.out.println("  OK Camionero creado."); }); break;
                case 2: ejecutar(() -> { var l = camioneroDAO.listar(); if (l.isEmpty()) System.out.println("  (sin registros)"); l.forEach(System.out::println); }); break;
                case 3: ejecutar(() -> { Camionero c = camioneroDAO.buscarPorId(Entrada.id("ID")); System.out.println(c == null ? "  X No encontrado." : c); }); break;
                case 4: ejecutar(() -> {
                        int id = Entrada.id("ID a actualizar");
                        if (camioneroDAO.buscarPorId(id) == null) { System.out.println("  X No encontrado."); return; }
                        Camionero c = leerCamionero(); c.setIdCamionero(id);
                        System.out.println(camioneroDAO.actualizar(c) ? "  OK Actualizado." : "  X No se actualizo.");
                    }); break;
                case 5: ejecutar(() -> {
                        int id = Entrada.id("ID a eliminar");
                        if (camioneroDAO.buscarPorId(id) == null) { System.out.println("  X No encontrado."); return; }
                        if (Entrada.confirmar("Seguro que desea eliminar")) System.out.println(camioneroDAO.eliminar(id) ? "  OK Eliminado." : "  X No se elimino.");
                    }); break;
                default: break;
            }
        } while (op != 0);
    }

    // ---------------- CAMION ----------------
    private static Camion leerCamion(int idActual) throws SQLException {
        Camion c = new Camion();
        String placa;
        while (true) {
            placa = Entrada.placa("No. de placa");
            if (!camionDAO.existePlaca(placa, idActual)) break;
            System.out.println("  X Ya existe un camion con esa placa.");
        }
        c.setNoPlaca(placa);
        c.setModelo(Entrada.texto("Modelo", 45));
        c.setTipo(Entrada.texto("Tipo", 45));
        c.setPotencia(Entrada.entero("Potencia (HP, 1-2000)", 1, 2000));
        return c;
    }

    private static void menuCamion() {
        int op;
        do {
            op = submenu("CAMIONES");
            switch (op) {
                case 1: ejecutar(() -> { camionDAO.crear(leerCamion(0)); System.out.println("  OK Camion creado."); }); break;
                case 2: ejecutar(() -> { var l = camionDAO.listar(); if (l.isEmpty()) System.out.println("  (sin registros)"); l.forEach(System.out::println); }); break;
                case 3: ejecutar(() -> { Camion c = camionDAO.buscarPorId(Entrada.id("ID")); System.out.println(c == null ? "  X No encontrado." : c); }); break;
                case 4: ejecutar(() -> {
                        int id = Entrada.id("ID a actualizar");
                        if (camionDAO.buscarPorId(id) == null) { System.out.println("  X No encontrado."); return; }
                        Camion c = leerCamion(id); c.setIdCamion(id);
                        System.out.println(camionDAO.actualizar(c) ? "  OK Actualizado." : "  X No se actualizo.");
                    }); break;
                case 5: ejecutar(() -> {
                        int id = Entrada.id("ID a eliminar");
                        if (camionDAO.buscarPorId(id) == null) { System.out.println("  X No encontrado."); return; }
                        if (Entrada.confirmar("Seguro que desea eliminar")) System.out.println(camionDAO.eliminar(id) ? "  OK Eliminado." : "  X No se elimino.");
                    }); break;
                default: break;
            }
        } while (op != 0);
    }

    // ---------------- PAQUETE ----------------
    private static Paquete leerPaquete() throws SQLException {
        Paquete p = new Paquete();
        p.setDescripcion(Entrada.texto("Descripcion", 45));
        p.setDestinatario(Entrada.nombre("Destinatario", 45));
        p.setDireccionEnvio(Entrada.texto("Direccion de envio", 45));
        while (true) {
            int id = Entrada.id("ID del camionero");
            if (camioneroDAO.buscarPorId(id) != null) { p.setIdCamionero(id); break; }
            System.out.println("  X El camionero no existe.");
        }
        while (true) {
            int id = Entrada.id("ID de la ciudad");
            if (ciudadDAO.buscarPorId(id) != null) { p.setIdCiudad(id); break; }
            System.out.println("  X La ciudad no existe.");
        }
        return p;
    }

    private static void menuPaquete() {
        int op;
        do {
            op = submenu("PAQUETES");
            switch (op) {
                case 1: ejecutar(() -> { paqueteDAO.crear(leerPaquete()); System.out.println("  OK Paquete creado."); }); break;
                case 2: ejecutar(() -> { var l = paqueteDAO.listar(); if (l.isEmpty()) System.out.println("  (sin registros)"); l.forEach(System.out::println); }); break;
                case 3: ejecutar(() -> { Paquete p = paqueteDAO.buscarPorId(Entrada.id("ID")); System.out.println(p == null ? "  X No encontrado." : p); }); break;
                case 4: ejecutar(() -> {
                        int id = Entrada.id("ID a actualizar");
                        if (paqueteDAO.buscarPorId(id) == null) { System.out.println("  X No encontrado."); return; }
                        Paquete p = leerPaquete(); p.setIdPaquete(id);
                        System.out.println(paqueteDAO.actualizar(p) ? "  OK Actualizado." : "  X No se actualizo.");
                    }); break;
                case 5: ejecutar(() -> {
                        int id = Entrada.id("ID a eliminar");
                        if (paqueteDAO.buscarPorId(id) == null) { System.out.println("  X No encontrado."); return; }
                        if (Entrada.confirmar("Seguro que desea eliminar")) System.out.println(paqueteDAO.eliminar(id) ? "  OK Eliminado." : "  X No se elimino.");
                    }); break;
                default: break;
            }
        } while (op != 0);
    }

    // ---------------- CAMIONERO-CAMION ----------------
    private static CamioneroCamion leerAsignacion(int idActual) throws SQLException {
        CamioneroCamion x = new CamioneroCamion();
        while (true) {
            int idCr;
            while (true) {
                idCr = Entrada.id("ID del camionero");
                if (camioneroDAO.buscarPorId(idCr) != null) break;
                System.out.println("  X El camionero no existe.");
            }
            int idCa;
            while (true) {
                idCa = Entrada.id("ID del camion");
                if (camionDAO.buscarPorId(idCa) != null) break;
                System.out.println("  X El camion no existe.");
            }
            if (asignacionDAO.existeAsignacion(idCr, idCa, idActual)) {
                System.out.println("  X Esa asignacion ya existe. Intente de nuevo.");
                continue;
            }
            x.setIdCamionero(idCr);
            x.setIdCamion(idCa);
            return x;
        }
    }

    private static void menuAsignacion() {
        int op;
        do {
            op = submenu("CAMIONERO - CAMION");
            switch (op) {
                case 1: ejecutar(() -> { asignacionDAO.crear(leerAsignacion(0)); System.out.println("  OK Asignacion creada."); }); break;
                case 2: ejecutar(() -> { var l = asignacionDAO.listar(); if (l.isEmpty()) System.out.println("  (sin registros)"); l.forEach(System.out::println); }); break;
                case 3: ejecutar(() -> { CamioneroCamion x = asignacionDAO.buscarPorId(Entrada.id("ID")); System.out.println(x == null ? "  X No encontrado." : x); }); break;
                case 4: ejecutar(() -> {
                        int id = Entrada.id("ID a actualizar");
                        if (asignacionDAO.buscarPorId(id) == null) { System.out.println("  X No encontrado."); return; }
                        CamioneroCamion x = leerAsignacion(id); x.setIdCamioneroCamion(id);
                        System.out.println(asignacionDAO.actualizar(x) ? "  OK Actualizado." : "  X No se actualizo.");
                    }); break;
                case 5: ejecutar(() -> {
                        int id = Entrada.id("ID a eliminar");
                        if (asignacionDAO.buscarPorId(id) == null) { System.out.println("  X No encontrado."); return; }
                        if (Entrada.confirmar("Seguro que desea eliminar")) System.out.println(asignacionDAO.eliminar(id) ? "  OK Eliminado." : "  X No se elimino.");
                    }); break;
                default: break;
            }
        } while (op != 0);
    }

    // ---------------- CIUDAD ----------------
    private static void menuCiudad() {
        int op;
        do {
            op = submenu("CIUDADES");
            switch (op) {
                case 1: ejecutar(() -> { ciudadDAO.crear(new Ciudad(0, Entrada.nombre("Nombre", 45))); System.out.println("  OK Ciudad creada."); }); break;
                case 2: ejecutar(() -> { var l = ciudadDAO.listar(); if (l.isEmpty()) System.out.println("  (sin registros)"); l.forEach(System.out::println); }); break;
                case 3: ejecutar(() -> { Ciudad c = ciudadDAO.buscarPorId(Entrada.id("ID")); System.out.println(c == null ? "  X No encontrado." : c); }); break;
                case 4: ejecutar(() -> {
                        int id = Entrada.id("ID a actualizar");
                        if (ciudadDAO.buscarPorId(id) == null) { System.out.println("  X No encontrado."); return; }
                        System.out.println(ciudadDAO.actualizar(new Ciudad(id, Entrada.nombre("Nuevo nombre", 45))) ? "  OK Actualizado." : "  X No se actualizo.");
                    }); break;
                case 5: ejecutar(() -> {
                        int id = Entrada.id("ID a eliminar");
                        if (ciudadDAO.buscarPorId(id) == null) { System.out.println("  X No encontrado."); return; }
                        if (Entrada.confirmar("Seguro que desea eliminar")) System.out.println(ciudadDAO.eliminar(id) ? "  OK Eliminado." : "  X No se elimino.");
                    }); break;
                default: break;
            }
        } while (op != 0);
    }
}

