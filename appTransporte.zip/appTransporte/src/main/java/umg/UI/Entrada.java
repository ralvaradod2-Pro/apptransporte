
package umg.UI;

import java.util.Scanner;

/** Lectura de datos por consola con validaciones. */
public class Entrada {
    private static final Scanner sc = new Scanner(System.in);

    public static String texto(String etiqueta, int max) {
        while (true) {
            System.out.print(etiqueta + ": ");
            String s = sc.nextLine().trim();
            if (s.isEmpty()) System.out.println("  X El campo no puede estar vacio.");
            else if (s.length() > max) System.out.println("  X Maximo " + max + " caracteres.");
            else return s;
        }
    }

    /** Solo letras, espacios, punto, guion y apostrofe. */
    public static String nombre(String etiqueta, int max) {
        while (true) {
            String s = texto(etiqueta, max);
            if (s.matches("^[\\p{L} .'-]+$")) return s;
            System.out.println("  X Solo se permiten letras y espacios.");
        }
    }

    /** Telefono de 8 digitos (Guatemala), con guion opcional. */
    public static String telefono(String etiqueta) {
        while (true) {
            String s = texto(etiqueta, 20).replace("-", "").replace(" ", "");
            if (s.matches("\\d{8}")) return s;
            System.out.println("  X El telefono debe tener 8 digitos numericos.");
        }
    }

    /** Placa alfanumerica de 5 a 10 caracteres, se guarda en mayusculas. */
    public static String placa(String etiqueta) {
        while (true) {
            String s = texto(etiqueta, 10).toUpperCase().replace("-", "").replace(" ", "");
            if (s.matches("[A-Z0-9]{5,10}")) return s;
            System.out.println("  X Placa invalida (alfanumerica, 5 a 10 caracteres). Ej: P123ABC");
        }
    }

    public static int entero(String etiqueta, int min, int max) {
        while (true) {
            System.out.print(etiqueta + ": ");
            try {
                int n = Integer.parseInt(sc.nextLine().trim());
                if (n >= min && n <= max) return n;
                System.out.println("  X Debe estar entre " + min + " y " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("  X Ingrese un numero entero valido.");
            }
        }
    }

    public static int id(String etiqueta) { return entero(etiqueta, 1, Integer.MAX_VALUE); }

    public static double decimalPositivo(String etiqueta) {
        while (true) {
            System.out.print(etiqueta + ": ");
            try {
                double d = Double.parseDouble(sc.nextLine().trim());
                if (d > 0 && d < 10_000_000_000_000.0) return d;
                System.out.println("  X Debe ser mayor que 0.");
            } catch (NumberFormatException e) {
                System.out.println("  X Ingrese un numero valido.");
            }
        }
    }

    public static boolean confirmar(String pregunta) {
        while (true) {
            System.out.print(pregunta + " (S/N): ");
            String s = sc.nextLine().trim().toUpperCase();
            if (s.equals("S")) return true;
            if (s.equals("N")) return false;
        }
    }
}

