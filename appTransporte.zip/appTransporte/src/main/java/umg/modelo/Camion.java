
package umg.modelo;
public class Camion {
    private int idCamion, potencia;
    private String noPlaca, modelo, tipo;
    
    public Camion() {}

    public int getIdCamion() { return idCamion; }
    public void setIdCamion(int idCamion) { this.idCamion = idCamion; }
    public String getNoPlaca() { return noPlaca; }
    public void setNoPlaca(String noPlaca) { this.noPlaca = noPlaca; }
    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public int getPotencia() { return potencia; }
    public void setPotencia(int potencia) { this.potencia = potencia; }

    @Override
    public String toString() {
        return String.format("ID: %-4d | Placa: %-10s | Modelo: %-15s | Tipo: %-15s | Potencia: %d HP",
                idCamion, noPlaca, modelo, tipo, potencia);
    }
}