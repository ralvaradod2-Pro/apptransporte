
package umg.modelo;

public class Camionero {
    private int idCamionero;
    private String nombre, telefono, direccion, poblacion;
    private double salario;

    public Camionero() {}

    public int getIdCamionero() { return idCamionero; }
    public void setIdCamionero(int idCamionero) { this.idCamionero = idCamionero; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }
    public double getSalario() { return salario; }
    public void setSalario(double salario) { this.salario = salario; }
    public String getPoblacion() { return poblacion; }
    public void setPoblacion(String poblacion) { this.poblacion = poblacion; }

    @Override
    public String toString() {
        return String.format("ID: %-4d | %-25s | Tel: %-10s | Dir: %-25s | Q%,.2f | Poblacion: %s",
                idCamionero, nombre, telefono, direccion, salario, poblacion);
    }
}

