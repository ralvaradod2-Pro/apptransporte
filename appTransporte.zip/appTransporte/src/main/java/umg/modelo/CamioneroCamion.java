
  package umg.modelo;

public class CamioneroCamion {
    private int idCamioneroCamion, idCamionero, idCamion;
    private String nombreCamionero, placaCamion;

    public CamioneroCamion() {
    }

    public int getIdCamioneroCamion() { return idCamioneroCamion; }
    public void setIdCamioneroCamion(int id) { this.idCamioneroCamion = id; }

    public int getIdCamionero() { return idCamionero; }
    public void setIdCamionero(int idCamionero) { this.idCamionero = idCamionero; }

    public int getIdCamion() { return idCamion; }
    public void setIdCamion(int idCamion) { this.idCamion = idCamion; }

    public String getNombreCamionero() { return nombreCamionero; }
    public void setNombreCamionero(String n) { this.nombreCamionero = n; }

    public String getPlacaCamion() { return placaCamion; }
    public void setPlacaCamion(String p) { this.placaCamion = p; }

    @Override
    public String toString() {
        return String.format("ID: %-4d | Camionero: %s (#%d) | Camion: %s (#%d)",
                idCamioneroCamion,
                nombreCamionero == null ? "-" : nombreCamionero, idCamionero,
                placaCamion == null ? "-" : placaCamion, idCamion);
    }
}
    

