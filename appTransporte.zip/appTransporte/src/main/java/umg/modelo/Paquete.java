
package umg.modelo;

public class Paquete {
    private int idPaquete, idCamionero, idCiudad;
    private String descripcion, destinatario, direccionEnvio;
    // Solo para mostrar (JOIN)
    private String nombreCamionero, nombreCiudad;

    public Paquete() {}

    public int getIdPaquete() { return idPaquete; }
    public void setIdPaquete(int idPaquete) { this.idPaquete = idPaquete; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public String getDestinatario() { return destinatario; }
    public void setDestinatario(String destinatario) { this.destinatario = destinatario; }
    public String getDireccionEnvio() { return direccionEnvio; }
    public void setDireccionEnvio(String direccionEnvio) { this.direccionEnvio = direccionEnvio; }
    public int getIdCamionero() { return idCamionero; }
    public void setIdCamionero(int idCamionero) { this.idCamionero = idCamionero; }
    public int getIdCiudad() { return idCiudad; }
    public void setIdCiudad(int idCiudad) { this.idCiudad = idCiudad; }
    public String getNombreCamionero() { return nombreCamionero; }
    public void setNombreCamionero(String n) { this.nombreCamionero = n; }
    public String getNombreCiudad() { return nombreCiudad; }
    public void setNombreCiudad(String n) { this.nombreCiudad = n; }

    @Override
    public String toString() {
        return String.format("ID: %-4d | %-20s | Dest: %-18s | Dir: %-22s | Camionero: %s (#%d) | Ciudad: %s (#%d)",
                idPaquete, descripcion, destinatario, direccionEnvio,
                nombreCamionero == null ? "-" : nombreCamionero, idCamionero,
                nombreCiudad == null ? "-" : nombreCiudad, idCiudad);
    }
}
